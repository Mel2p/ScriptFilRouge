Chat Lib
======================================


Module instalable avec pip:
	
	pip install git+git://github.comp/Mel2p/ScriptFilRouge.git


Ce code est sous license WTFPL. 
